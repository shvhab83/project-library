
document.querySelectorAll('.navbar-item').forEach((nav) => {
    nav.addEventListener('click', () => {
        document.querySelectorAll('section').forEach((elem) => {
            if (elem.id === nav.dataset.block) {
                elem.scrollIntoView({behavior: 'smooth'})
            }
        })
    });
});

document.querySelector('.btn-success').addEventListener('click',()=>{
    document.querySelector(".input-section").classList.toggle('scale-up-top');
})




