<?php
require_once './components/db.php';
$members = selectMembers();
?>

<?php require_once "./components/header.php"; ?>
<main>
    <div class="container">
        <section class="index-top">
            <div class="parallax">
                <div class="parallax-effect">
                </div>
                <h1>کتابخانه دانشمندان</h1>
                <h2>آرامش و دانش را در کنار ما تجربه کنید</h2>
            </div>
        </section>
        <section id="article" class="card-section">
            <div class="cards">
                <div class="card">
                    <div class="card-image">
                        <img src="./assets/images/banner2.jpg" alt="">
                    </div>
                    <div class="card-text">
                        <h2 class="card-header">کتاب های متنوع</h2>
                    </div>
                </div>

                <div class="card">
                    <div class="card-image">
                        <img src="./assets/images/banner1.png" alt="">
                    </div>
                    <div class="card-text">
                        <h2 class="card-header">سکوت و آرامش</h2>
                    </div>
                </div>
                <div class="card">
                    <div class="card-image">
                        <img src="./assets/images/banner3.png" alt="">
                    </div>
                    <div class="card-text">
                        <h2 class="card-header">همراه با امکانات رفاهی</h2>
                    </div>
                </div>
            </div>
        </section>
        <section class="members-section" id="members">
            <h1>اعضا کتابخانه</h1>
            <table class="member-table">
                <tr>
                    <th>نام</th>
                    <th>نام خانواده گی</th>
                    <th>شماره شناسنامه</th>
                    <th>شماره ملی</th>
                    <th>حذف</th>
                    <th>ادیت</th>
                </tr>
                <?php foreach ($members as $member): ?>
                    <tr>
                        <td><?php echo $member['firstName'] ?></td>
                        <td><?php echo $member['lastName'] ?></td>
                        <td><?php echo $member['IdNumber'] ?></td>
                        <td><?php echo $member['BirthCertificateId'] ?></td>
                        <td>
                            <form method="post" action="components/delete.php">
                                <input type="hidden" name="id" value="<?php echo $member['id'] ?>">
                                <button class="delete" type="submit">
                                    <svg class="delete-icon" xmlns="http://www.w3.org/2000/svg" height="20" width="18"
                                         fill="red" viewBox="0 0 448 512">
                                        <path d="M135.2 17.7L128 32H32C14.3 32 0 46.3 0 64S14.3 96 32 96H416c17.7 0 32-14.3 32-32s-14.3-32-32-32H320l-7.2-14.3C307.4 6.8 296.3 0 284.2 0H163.8c-12.1 0-23.2 6.8-28.6 17.7zM416 128H32L53.2 467c1.6 25.3 22.6 45 47.9 45H346.9c25.3 0 46.3-19.7 47.9-45L416 128z"/>
                                    </svg>
                                </button>
                            </form>
                        </td>
                        <td>
                            <form method="post" action="./edit.php">
                                <input type="hidden" name="id" value="<?php echo $member['id'] ?>">
                                <button class="update" type="submit" value="تغییر مشخصات">
                                    <svg xmlns="http://www.w3.org/2000/svg" height="20" width="20" viewBox="0 0 512 512"><!--!Font Awesome Free 6.5.1 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free Copyright 2023 Fonticons, Inc.--><path d="M471.6 21.7c-21.9-21.9-57.3-21.9-79.2 0L362.3 51.7l97.9 97.9 30.1-30.1c21.9-21.9 21.9-57.3 0-79.2L471.6 21.7zm-299.2 220c-6.1 6.1-10.8 13.6-13.5 21.9l-29.6 88.8c-2.9 8.6-.6 18.1 5.8 24.6s15.9 8.7 24.6 5.8l88.8-29.6c8.2-2.7 15.7-7.4 21.9-13.5L437.7 172.3 339.7 74.3 172.4 241.7zM96 64C43 64 0 107 0 160V416c0 53 43 96 96 96H352c53 0 96-43 96-96V320c0-17.7-14.3-32-32-32s-32 14.3-32 32v96c0 17.7-14.3 32-32 32H96c-17.7 0-32-14.3-32-32V160c0-17.7 14.3-32 32-32h96c17.7 0 32-14.3 32-32s-14.3-32-32-32H96z"/></svg>
                                </button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </table>
        </section>
        <div class="hide-button">
            <button class="btn-success">عضویت در کتابخانه</button>
        </div>
        <section id="addMember" class="input-section input-animate">
            <form method="post" action="components/create.php">
                <div class="input-form">
                    <div class="input-name-section">
                        <label for="firstName">نام</label>
                        <input type="text" placeholder="نام خود را وارد کنید" name="firstName" id="firstName"/>
                        <label for="lastName">نام خانواده گی</label>
                        <input type="text" placeholder="نام خانواده گی خود را وارد کنید" name="lastName" id="lastName"/>
                    </div>
                    <div class="input-name-section">
                        <label for="IdNumber">شماره ملی</label>
                        <input type="text" placeholder="شماره ملی خود را وارد کنید" name="IdNumber" id="IdNumber"/>
                        <label for="BirthCertificateId">شماره شناسنامه</label>
                        <input type="text" placeholder="شماره شناسنامه خود را وارد کنید" name="BirthCertificateId"
                               id="BirthCertificateId"/>
                    </div>
                </div>
                <input type="submit" class="btn btn-submit" value="ثبت اطلاعات"/>
            </form>
        </section>
    </div>
</main>
<?php require_once './components/footer.php' ?>
