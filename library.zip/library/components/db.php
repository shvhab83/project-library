<?php
function connectToDataBase()
{
    $conn = new mysqli("localhost", "root", "", "library");
    return $conn;
}

function insertToDataBase($firstName, $lastName, $IdNumber, $BirthCertificateId)
{
    $conn = connectToDataBase();
    $sql = "insert into members (firstName, lastName, IdNumber, BirthCertificateId) values('$firstName','$lastName','$IdNumber','$BirthCertificateId')";
    mysqli_query($conn, $sql);
    $conn->close();
}

function selectMembers()
{
    $conn = connectToDataBase();
    $sql = 'select * from members';
    $query = mysqli_query($conn, $sql);
    return $query;
}


function selectById($id)
{
    $conn = connectToDataBase();
    $sql = "select * from members where id = $id";
    $query = mysqli_query($conn, $sql);
    $member = mysqli_fetch_assoc($query);
    return $member;
}

function deleteMember($id)
{
    $conn = connectToDataBase();
    $sql = "delete from members where id= $id";
    mysqli_query($conn, $sql);
}

function updateMember($id, $firstName, $lastName, $IdNumber, $BirthCertificateId)
{
    $conn = connectToDataBase();
    $sql = "UPDATE members SET firstName='$firstName', lastName='$lastName', IdNumber='$IdNumber', BirthCertificateId='$BirthCertificateId' WHERE id = $id";
    mysqli_query($conn, $sql);
}
