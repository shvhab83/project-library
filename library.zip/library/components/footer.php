<footer>
    <div class="footer-section">
        <ul class="footer-list">
            <li class="footer-list-item"><a href="#">خانه</a></li>
            <li class="footer-list-item"><a href="#">درباره ما</a></li>
            <li class="footer-list-item"><a href="#">ارتباط با ادمین</a></li>

        </ul>
        <div class="footer-logo">
            <img src="./assets/images/logo.jpg" alt="website-logo" class="footer-image">
        </div>
    </div>
</footer>

<script defer src="https://use.fontawesome.com/releases/v5.15.4/js/all.js" integrity="sha384-rOA1PnstxnOBLzCLMcre8ybwbTmemjzdNlILg8O7z1lUkLXozs4DHonlDtnE7fpc" crossorigin="anonymous"></script>
<script src="./assets/js/script.js"></script>


</body>
</html>
