<?php
require_once './db.php';
$id = $_POST['id'];
deleteMember($id);
header('location:../index.php', true);
?>