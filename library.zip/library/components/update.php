<?php
require_once './db.php';

$id = $_POST["id"];
$firstName = $_POST["firstName"];
$lastName = $_POST["lastName"];
$IdNumber = $_POST["IdNumber"];
$BirthCertificateId = $_POST["BirthCertificateId"];

updateMember($id,$firstName,$lastName,$IdNumber,$BirthCertificateId);

header('location:../index.php', true);