<?php

// error_reporting(0);
session_start();

require_once './db.php';

$firstName = $_POST["firstName"];

$lastName = $_POST["lastName"];

$IdNumber = $_POST["IdNumber"];

$BirthCertificateId = $_POST["BirthCertificateId"];

if ($firstName && $lastName && $IdNumber && $BirthCertificateId) {
    insertToDataBase($firstName,$lastName,$IdNumber,$BirthCertificateId);
}


header('location:../index.php', true);

?>
