<?php
require_once './components/db.php';
$id = $_POST['id'];
$member = selectById($id);
?>
<?php require_once "./components/header.php" ?>

<main>
    <div class="container">

        <section class="input-section">
            <h1 class="input-header">صفحه ی ادیت</h1>
            <form method="post" action="components/update.php">
                <div class="input-form">
                    <div class="input-name-section">
                        <label for="firstName">نام</label>
                        <input type="text" value="<?php echo $member['firstName'] ?>" name="firstName" id="firstName"/>
                        <label for="lastName">نام خانواده گی</label>
                        <input type="text" value="<?php echo $member['lastName'] ?>" name="lastName" id="lastName"/>
                    </div>
                    <div class="input-name-section">
                        <label for="IdNumber">شماره ملی</label>
                        <input type="text" value="<?php echo $member['IdNumber'] ?>" name="IdNumber" id="IdNumber"/>
                        <label for="BirthCertificateId">شماره شناسنامه</label>
                        <input type="text" value="<?php echo $member['BirthCertificateId'] ?>" name="BirthCertificateId"
                               id="BirthCertificateId"/>
                        <input type="hidden" name="id" value="<?php echo $member['id'] ?>">
                    </div>
                </div>
                <input type="submit" class="btn btn-submit" value="تغییر اطلاعات"/>
            </form>
        </section>
    </div>
</main>
<?php require_once "./components/footer.php" ?>

